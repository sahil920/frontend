import "./App.css";
import "./index.css";
// import { Container } from "react-bootstrap";
import Footer from "./components/Footer";
import Header from "./components/Header";
import HomeScreen from "./screens/HomeScreen";
import Container from "react-bootstrap/Container";
import CartScreen from "./screens/CartScreen";
import ProductScreen from "./screens/ProductScreen";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import ProductDetails from "./screens/ProductDetails";
function App() {
  return (
    <Router>
      <Header />
      <main className="my-3">
        <Container>
          <Routes>
           <Route path="/" element={<HomeScreen />} />
            <Route  path="/product/:id" element={<ProductDetails/>} exact/> 
            <Route  path="/cart/:id?" element={<CartScreen/>} exact/> 
          </Routes>
        </Container>
      </main>
      <Footer />
    </Router>         
  );
}
export default App;
