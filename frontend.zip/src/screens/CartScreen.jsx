import React from 'react'

const cartScreen = () => {
    return (
        <div>cartScreen</div>
    )
}

export default cartScreen