import React from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { Link } from "react-router-dom";
import "../index.css";
const Header = () => {
    return (
        <Navbar bg="dark" expand="lg" variant="dark">
            <Container>
                <Link to={"/"} style={{ textDecoration: "none" }}>
                    <Navbar.Brand>E-Commerce</Navbar.Brand>
                </Link>

                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ml-500px">
                        {/* <Link to={"/cart"} style={{ textDecoration: "none" }}> */}
                        <Link to={"/cart"} >
                            <i className="fas fa-shopping-cart"></i>&nbsp; Cart
                        </Link>
                        {/* </Link> */}
                        {/* <Link to={"/signin"} style={{ textDecoration: "none" }}> */}
                        <Link to={"/signin"} >
                            <i className="fas fa-user"></i>&nbsp;SignIn
                        </Link>
                        {/* </Link> */}
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
};

export default Header;
